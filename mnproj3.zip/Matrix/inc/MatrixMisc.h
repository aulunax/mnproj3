#include <iostream>
#include <string>

namespace Mat {

int countOccurrences(const std::string& str, char ch);



}