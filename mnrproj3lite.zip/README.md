# Interpolations
## Platform
Use Linux (preferably Ubuntu, but others should work)
## Running
```sh
python3 main.py
```
## Troubleshooting
If python can't find py_matrix module, try compiling it from scratch using the instructions in Matrix README.md, then copying created py_matrix.so file into root directory of this project